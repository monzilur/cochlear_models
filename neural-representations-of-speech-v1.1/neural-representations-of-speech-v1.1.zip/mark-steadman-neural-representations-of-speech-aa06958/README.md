## Synopsis

This set of scripts accompanies a journal article submitted to Frontiers in Neuroscience and will be updated upon publication.

## License

MIT. For a full description, see LICENSE.txt
